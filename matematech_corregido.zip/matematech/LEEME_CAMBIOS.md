# Cambios realizados

1. `static/CSS` -> `static/css` (las plantillas piden `/css/styles.css`; en Linux/macOS fallaba).
2. `database/schema.sql` (esquema deducido del código) y `database/seed_demo.sql` (evaluación demo de 3 preguntas).
3. `DocenteController`: el dashboard ahora carga evaluaciones, preguntas, competencias, resultados y estadísticas reales, y soporta editar evaluación/pregunta.
4. Flujo del estudiante (`SimulacroController` + `evaluacion.html`):
   entra a `/evaluacion/{id}` -> recibe preguntas (sin la respuesta correcta) -> responde -> el servidor valida,
   suma 1 punto por acierto, guarda RESULTADO y RESPUESTA -> se muestra el resultado con revisión.
5. `HomeController`/`dashboard.html`: lista de simulacros reales y desempeño por competencia del último resultado.
6. `PreguntaController`: al editar una pregunta ya no se borran las opciones (se actualizan) y la pregunta se mueve de evaluación correctamente.

Se excluyó `target/` del zip (compilados viejos).

## Cómo probar
1. `mysql -u root -p < database/schema.sql`  (y opcional `database/seed_demo.sql`)
2. `./mvnw spring-boot:run`
3. Regístrate como Estudiante, entra al dashboard y abre el simulacro.
