-- Datos de prueba OPCIONALES: 1 evaluación con 3 preguntas.
-- Ejecutar después de schema.sql:  mysql -u root -p < database/seed_demo.sql
USE sistema_evaluaciones;

INSERT INTO EVALUACION (titulo, descripcion, tiempoLimite, fechaCreacion)
VALUES ('Simulacro Saber 11 #1 (demo)', 'Evaluación de prueba con 3 preguntas', 15, CURDATE());
SET @ev = LAST_INSERT_ID();

-- Pregunta 1
INSERT INTO PREGUNTA (enunciado, explicacion, nivelDificultad, id_competencia)
VALUES ('¿Cuál es el resultado de 3/4 + 1/4?', 'Mismos denominadores: (3+1)/4 = 4/4 = 1.', 'Fácil', 2);
SET @p1 = LAST_INSERT_ID();
INSERT INTO OPCION (letra, texto, esCorrecta, id_pregunta) VALUES
    ('A', '1/2', FALSE, @p1), ('B', '1', TRUE, @p1), ('C', '4/8', FALSE, @p1), ('D', '3/16', FALSE, @p1);
INSERT INTO EVALUACION_PREGUNTA (id_evaluacion, id_pregunta, ordenPregunta) VALUES (@ev, @p1, 1);

-- Pregunta 2
INSERT INTO PREGUNTA (enunciado, explicacion, nivelDificultad, id_competencia)
VALUES ('Si f(x) = 2x + 3, ¿cuánto vale f(5)?', 'f(5) = 2·5 + 3 = 13.', 'Fácil', 1);
SET @p2 = LAST_INSERT_ID();
INSERT INTO OPCION (letra, texto, esCorrecta, id_pregunta) VALUES
    ('A', '10', FALSE, @p2), ('B', '15', FALSE, @p2), ('C', '13', TRUE, @p2), ('D', '8', FALSE, @p2);
INSERT INTO EVALUACION_PREGUNTA (id_evaluacion, id_pregunta, ordenPregunta) VALUES (@ev, @p2, 2);

-- Pregunta 3
INSERT INTO PREGUNTA (enunciado, explicacion, nivelDificultad, id_competencia)
VALUES ('Se lanza un dado justo de 6 caras. ¿Cuál es la probabilidad de obtener un número par?', 'Hay 3 pares (2, 4, 6) de 6 resultados: 3/6 = 1/2.', 'Medio', 3);
SET @p3 = LAST_INSERT_ID();
INSERT INTO OPCION (letra, texto, esCorrecta, id_pregunta) VALUES
    ('A', '1/6', FALSE, @p3), ('B', '1/3', FALSE, @p3), ('C', '2/3', FALSE, @p3), ('D', '1/2', TRUE, @p3);
INSERT INTO EVALUACION_PREGUNTA (id_evaluacion, id_pregunta, ordenPregunta) VALUES (@ev, @p3, 3);
