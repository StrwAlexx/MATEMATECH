-- MatemaTech - esquema MySQL 8
-- Deducido de las consultas SQL que usa la aplicación.
-- Es idempotente: usa CREATE TABLE IF NOT EXISTS, no borra datos.
-- Ejecutar:  mysql -u root -p < database/schema.sql

CREATE DATABASE IF NOT EXISTS sistema_evaluaciones
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_evaluaciones;

CREATE TABLE IF NOT EXISTS USUARIO (
    id_usuario  INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(100) NOT NULL,
    correo      VARCHAR(150) NOT NULL UNIQUE,
    contrasena  VARCHAR(100) NOT NULL,          -- hash BCrypt (60 chars)
    rol         VARCHAR(20)  NOT NULL           -- 'Estudiante' | 'Docente'
);

CREATE TABLE IF NOT EXISTS DOCENTE (
    id_usuario  INT PRIMARY KEY,
    asignatura  VARCHAR(100) NOT NULL DEFAULT 'General',
    FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ESTUDIANTE (
    id_usuario  INT PRIMARY KEY,
    grado       VARCHAR(10) NOT NULL DEFAULT '11',
    FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS COMPETENCIA (
    id_competencia INT AUTO_INCREMENT PRIMARY KEY,
    nombre         VARCHAR(100) NOT NULL,
    componente     VARCHAR(100)
);

CREATE TABLE IF NOT EXISTS EVALUACION (
    id_evaluacion  INT AUTO_INCREMENT PRIMARY KEY,
    titulo         VARCHAR(150) NOT NULL,
    descripcion    VARCHAR(500),
    tiempoLimite   INT NOT NULL DEFAULT 60,     -- minutos
    fechaCreacion  DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS PREGUNTA (
    id_pregunta     INT AUTO_INCREMENT PRIMARY KEY,
    enunciado       TEXT NOT NULL,
    explicacion     TEXT,
    nivelDificultad VARCHAR(20) NOT NULL,       -- Fácil | Medio | Difícil
    id_competencia  INT NOT NULL,
    FOREIGN KEY (id_competencia) REFERENCES COMPETENCIA(id_competencia)
);

CREATE TABLE IF NOT EXISTS OPCION (
    id_opcion    INT AUTO_INCREMENT PRIMARY KEY,
    letra        CHAR(1) NOT NULL,              -- A, B, C, D
    texto        VARCHAR(500) NOT NULL,
    esCorrecta   BOOLEAN NOT NULL DEFAULT FALSE,
    id_pregunta  INT NOT NULL,
    UNIQUE KEY uq_opcion_letra (id_pregunta, letra),
    FOREIGN KEY (id_pregunta) REFERENCES PREGUNTA(id_pregunta) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS EVALUACION_PREGUNTA (
    id_evaluacion  INT NOT NULL,
    id_pregunta    INT NOT NULL,
    ordenPregunta  INT NOT NULL DEFAULT 1,
    PRIMARY KEY (id_evaluacion, id_pregunta),   -- requerido por ON DUPLICATE KEY
    FOREIGN KEY (id_evaluacion) REFERENCES EVALUACION(id_evaluacion) ON DELETE CASCADE,
    FOREIGN KEY (id_pregunta)   REFERENCES PREGUNTA(id_pregunta)     ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS RESULTADO (
    id_resultado     INT AUTO_INCREMENT PRIMARY KEY,
    puntaje          DOUBLE NOT NULL,           -- 1 punto por respuesta correcta
    porcentaje       DOUBLE NOT NULL,           -- 0..100
    fechaRealizacion DATETIME NOT NULL,
    id_estudiante    INT NOT NULL,
    id_evaluacion    INT NOT NULL,
    FOREIGN KEY (id_estudiante) REFERENCES USUARIO(id_usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_evaluacion) REFERENCES EVALUACION(id_evaluacion) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS RESPUESTA (
    id_respuesta  INT AUTO_INCREMENT PRIMARY KEY,
    id_resultado  INT NOT NULL,
    id_pregunta   INT NOT NULL,
    id_opcion     INT NOT NULL,                 -- opción que eligió el estudiante
    FOREIGN KEY (id_resultado) REFERENCES RESULTADO(id_resultado) ON DELETE CASCADE,
    FOREIGN KEY (id_pregunta)  REFERENCES PREGUNTA(id_pregunta),
    FOREIGN KEY (id_opcion)    REFERENCES OPCION(id_opcion)
);

-- Competencias base (las mismas que muestra el dashboard)
INSERT IGNORE INTO COMPETENCIA (id_competencia, nombre, componente) VALUES
    (1, 'Razonamiento y Argumentación',      'Numérico-variacional'),
    (2, 'Ejecución y Planteamiento',         'Geométrico-métrico'),
    (3, 'Interpretación y Representación',   'Aleatorio');
