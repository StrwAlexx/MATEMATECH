package matematech.matematech.control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import matematech.matematech.modelo.Usuario;

@Controller
public class HomeController {

    @GetMapping({"/", "/login"})
    public String mostrarLogin() {
        return "login/login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String correo,
                                @RequestParam String contrasena,
                                HttpSession session,
                                Model model) {

        Usuario encontrado = UsuarioController.buscarPorCorreoYContrasena(correo, contrasena);

        if (encontrado != null) {
            session.setAttribute("usuario", encontrado);

            if ("Docente".equalsIgnoreCase(encontrado.getRol())) {
                return "redirect:/docente/dashboard";
            } else {
                return "redirect:/dashboard";
            }
        }

        model.addAttribute("error", "Correo o contraseña incorrectos.");
        return "login/login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "login/registro";
    }

    @PostMapping("/registro")
    public String procesarRegistro(Usuario usuario,
                                   @RequestParam(required = false) String codigoAdmin,
                                   Model model) {

        if ("DOCENTE".equalsIgnoreCase(usuario.getRol())) {
            usuario.setRol("Docente");
            if (codigoAdmin == null || !codigoAdmin.equals("ADMIN*")) {
                model.addAttribute("error", "Código de autorización docente incorrecto.");
                model.addAttribute("usuario", usuario);
                return "login/registro";
            }
        } else {
            usuario.setRol("Estudiante");
        }

        boolean exito = UsuarioController.guardar(usuario);
        if (!exito) {
            model.addAttribute("error", "El correo ya se encuentra registrado o hubo un error en la base de datos.");
            model.addAttribute("usuario", usuario);
            return "login/registro";
        }

        return "redirect:/login?registrado=true";
    }

    @GetMapping("/dashboard")
    public String mostrarDashboardEstudiante(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null || !"Estudiante".equalsIgnoreCase(usuario.getRol())) {
            session.invalidate();
            return "redirect:/login";
        }

        boolean yaHizoSimulacro = false;
        double porcentajeObtenido = 0.0;
        int idResultado = -1;
        int idUsuario = usuario.getId_usuario();
        List<Map<String, Object>> desempeno = new ArrayList<>();

        if (idUsuario > 0) {
            String sqlUltimo = "SELECT id_resultado, porcentaje FROM RESULTADO WHERE id_estudiante = ? ORDER BY id_resultado DESC LIMIT 1";
            String sqlComp = """
                    SELECT c.nombre AS competencia,
                           COUNT(*) AS total,
                           SUM(CASE WHEN o.esCorrecta = TRUE THEN 1 ELSE 0 END) AS correctas
                    FROM RESPUESTA resp
                    INNER JOIN PREGUNTA p ON p.id_pregunta = resp.id_pregunta
                    INNER JOIN COMPETENCIA c ON c.id_competencia = p.id_competencia
                    INNER JOIN OPCION o ON o.id_opcion = resp.id_opcion
                    WHERE resp.id_resultado = ?
                    GROUP BY c.id_competencia, c.nombre
                    ORDER BY c.id_competencia
                    """;

            Connection con = UsuarioController.conectar();
            if (con != null) {
                try (con) {
                    try (PreparedStatement pst = con.prepareStatement(sqlUltimo)) {
                        pst.setInt(1, idUsuario);
                        try (ResultSet rs = pst.executeQuery()) {
                            if (rs.next()) {
                                yaHizoSimulacro = true;
                                idResultado = rs.getInt("id_resultado");
                                porcentajeObtenido = rs.getDouble("porcentaje");
                            }
                        }
                    }
                    if (idResultado > 0) {
                        try (PreparedStatement pst = con.prepareStatement(sqlComp)) {
                            pst.setInt(1, idResultado);
                            try (ResultSet rs = pst.executeQuery()) {
                                while (rs.next()) {
                                    int total = rs.getInt("total");
                                    int correctas = rs.getInt("correctas");
                                    Map<String, Object> fila = new LinkedHashMap<>();
                                    fila.put("competencia", rs.getString("competencia"));
                                    fila.put("porcentaje", total > 0 ? Math.round(correctas * 1000.0 / total) / 10.0 : 0.0);
                                    desempeno.add(fila);
                                }
                            }
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        // Simulacros disponibles: solo evaluaciones que ya tienen preguntas
        List<Map<String, Object>> simulacros = new ArrayList<>();
        for (Map<String, Object> ev : EvaluacionController.listarEvaluaciones()) {
            if ((Integer) ev.get("total_preguntas") > 0) {
                simulacros.add(ev);
            }
        }

        model.addAttribute("usuario", usuario);
        model.addAttribute("yaHizoSimulacro", yaHizoSimulacro);
        model.addAttribute("porcentajeObtenido", porcentajeObtenido);
        model.addAttribute("desempeno", desempeno);
        model.addAttribute("simulacros", simulacros);

        return "login/dashboard";
    }

    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}