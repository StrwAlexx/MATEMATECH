package matematech.matematech.control;

import matematech.matematech.modelo.Usuario;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.sql.*;
import java.util.*;

@Controller
@RequestMapping("/docente/preguntas")
public class PreguntaController {

    private boolean esDocente(HttpSession session) {
        Usuario u = (Usuario) session.getAttribute("usuario");
        return u != null && "Docente".equalsIgnoreCase(u.getRol());
    }

    public static List<Map<String, Object>> listarCompetencias() {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = "SELECT id_competencia, nombre, componente FROM COMPETENCIA ORDER BY id_competencia ASC";

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> c = new LinkedHashMap<>();
                c.put("id_competencia", rs.getInt("id_competencia"));
                c.put("nombre", rs.getString("nombre"));
                c.put("componente", rs.getString("componente"));
                lista.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public static List<Map<String, Object>> listarPreguntas() {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = """
                SELECT p.id_pregunta, p.enunciado, p.explicacion, p.nivelDificultad, p.id_competencia,
                       c.nombre AS competencia_nombre, c.componente,
                       ep.id_evaluacion, e.titulo AS evaluacion_titulo
                FROM PREGUNTA p
                INNER JOIN COMPETENCIA c ON p.id_competencia = c.id_competencia
                LEFT JOIN EVALUACION_PREGUNTA ep ON p.id_pregunta = ep.id_pregunta
                LEFT JOIN EVALUACION e ON ep.id_evaluacion = e.id_evaluacion
                ORDER BY p.id_pregunta DESC
                """;

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                Map<String, Object> p = new LinkedHashMap<>();
                p.put("id_pregunta", rs.getInt("id_pregunta"));
                p.put("enunciado", rs.getString("enunciado"));
                p.put("explicacion", rs.getString("explicacion"));
                p.put("nivelDificultad", rs.getString("nivelDificultad"));
                p.put("id_competencia", rs.getInt("id_competencia"));
                p.put("competencia_nombre", rs.getString("competencia_nombre"));
                p.put("componente", rs.getString("componente"));
                p.put("id_evaluacion", rs.getObject("id_evaluacion"));
                p.put("evaluacion_titulo", rs.getString("evaluacion_titulo") != null ? rs.getString("evaluacion_titulo") : "Sin asignar");
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public static Map<String, Object> buscarPreguntaParaEditar(int idPregunta) {
        String sql = """
                SELECT p.id_pregunta, p.enunciado, p.explicacion, p.nivelDificultad, p.id_competencia,
                       ep.id_evaluacion
                FROM PREGUNTA p
                LEFT JOIN EVALUACION_PREGUNTA ep ON p.id_pregunta = ep.id_pregunta
                WHERE p.id_pregunta = ?
                LIMIT 1
                """;
        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idPregunta);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    Map<String, Object> p = new LinkedHashMap<>();
                    p.put("id_pregunta", rs.getInt("id_pregunta"));
                    p.put("enunciado", rs.getString("enunciado"));
                    p.put("explicacion", rs.getString("explicacion"));
                    p.put("nivelDificultad", rs.getString("nivelDificultad"));
                    p.put("id_competencia", rs.getInt("id_competencia"));
                    p.put("id_evaluacion", rs.getObject("id_evaluacion"));

                    String sqlOp = "SELECT letra, texto, esCorrecta FROM OPCION WHERE id_pregunta = ? ORDER BY letra ASC";
                    try (PreparedStatement pstOp = con.prepareStatement(sqlOp)) {
                        pstOp.setInt(1, idPregunta);
                        try (ResultSet rsOp = pstOp.executeQuery()) {
                            while (rsOp.next()) {
                                String letra = rsOp.getString("letra");
                                p.put("opcion" + letra, rsOp.getString("texto"));
                                if (rsOp.getBoolean("esCorrecta")) {
                                    p.put("correcta", letra);
                                }
                            }
                        }
                    }
                    return p;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @PostMapping("/guardar")
    public String guardarPregunta(@RequestParam(required = false) Integer idPregunta,
                                  @RequestParam(required = false) Integer idEvaluacion,
                                  @RequestParam int idCompetencia,
                                  @RequestParam String nivelDificultad,
                                  @RequestParam(required = false, defaultValue = "") String explicacion,
                                  @RequestParam String enunciado,
                                  @RequestParam String opcionA,
                                  @RequestParam String opcionB,
                                  @RequestParam String opcionC,
                                  @RequestParam String opcionD,
                                  @RequestParam String correcta,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        if (!esDocente(session)) {
            return "redirect:/login";
        }

        String correctaNorm = correcta == null ? "A" : correcta.trim().toUpperCase();
        Map<String, String> opciones = new LinkedHashMap<>();
        opciones.put("A", opcionA.trim());
        opciones.put("B", opcionB.trim());
        opciones.put("C", opcionC.trim());
        opciones.put("D", opcionD.trim());

        Connection con = null;
        try {
            con = UsuarioController.conectar();
            if (con == null) {
                redirectAttributes.addFlashAttribute("errorDocente", "Error de conexión con la base de datos.");
                return "redirect:/docente/dashboard#preguntas";
            }
            con.setAutoCommit(false);

            int preguntaIdFinal;
            if (idPregunta == null || idPregunta <= 0) {
                String sqlInsert = "INSERT INTO PREGUNTA (enunciado, explicacion, nivelDificultad, id_competencia) VALUES (?, ?, ?, ?)";
                try (PreparedStatement pst = con.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS)) {
                    pst.setString(1, enunciado.trim());
                    pst.setString(2, explicacion.trim());
                    pst.setString(3, nivelDificultad);
                    pst.setInt(4, idCompetencia);
                    pst.executeUpdate();
                    try (ResultSet keys = pst.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("No se obtuvo el ID de la pregunta.");
                        }
                        preguntaIdFinal = keys.getInt(1);
                    }
                }
            } else {
                String sqlUpdate = "UPDATE PREGUNTA SET enunciado = ?, explicacion = ?, nivelDificultad = ?, id_competencia = ? WHERE id_pregunta = ?";
                try (PreparedStatement pst = con.prepareStatement(sqlUpdate)) {
                    pst.setString(1, enunciado.trim());
                    pst.setString(2, explicacion.trim());
                    pst.setString(3, nivelDificultad);
                    pst.setInt(4, idCompetencia);
                    pst.setInt(5, idPregunta);
                    pst.executeUpdate();
                    preguntaIdFinal = idPregunta;
                }
            }

            if (idEvaluacion != null && idEvaluacion > 0) {
                try (PreparedStatement pstMove = con.prepareStatement(
                        "DELETE FROM EVALUACION_PREGUNTA WHERE id_pregunta = ? AND id_evaluacion <> ?")) {
                    pstMove.setInt(1, preguntaIdFinal);
                    pstMove.setInt(2, idEvaluacion);
                    pstMove.executeUpdate();
                }

                int siguienteOrden = 1;
                String sqlOrden = "SELECT COALESCE(MAX(ordenPregunta), 0) + 1 FROM EVALUACION_PREGUNTA WHERE id_evaluacion = ?";
                try (PreparedStatement pstOrd = con.prepareStatement(sqlOrden)) {
                    pstOrd.setInt(1, idEvaluacion);
                    try (ResultSet rsOrd = pstOrd.executeQuery()) {
                        if (rsOrd.next()) {
                            siguienteOrden = rsOrd.getInt(1);
                        }
                    }
                }

                String sqlLink = """
                        INSERT INTO EVALUACION_PREGUNTA (id_evaluacion, id_pregunta, ordenPregunta)
                        VALUES (?, ?, ?)
                        ON DUPLICATE KEY UPDATE id_evaluacion = VALUES(id_evaluacion)
                        """;
                try (PreparedStatement pstLink = con.prepareStatement(sqlLink)) {
                    pstLink.setInt(1, idEvaluacion);
                    pstLink.setInt(2, preguntaIdFinal);
                    pstLink.setInt(3, siguienteOrden);
                    pstLink.executeUpdate();
                }
            }

            // Upsert por (pregunta, letra): conserva el id_opcion para no romper RESPUESTA
            String sqlOpUpdate = "UPDATE OPCION SET texto = ?, esCorrecta = ? WHERE id_pregunta = ? AND letra = ?";
            String sqlOpInsert = "INSERT INTO OPCION (letra, texto, esCorrecta, id_pregunta) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstUp = con.prepareStatement(sqlOpUpdate);
                 PreparedStatement pstIns = con.prepareStatement(sqlOpInsert)) {
                for (Map.Entry<String, String> entry : opciones.entrySet()) {
                    boolean esCorrecta = entry.getKey().equals(correctaNorm);
                    pstUp.setString(1, entry.getValue());
                    pstUp.setBoolean(2, esCorrecta);
                    pstUp.setInt(3, preguntaIdFinal);
                    pstUp.setString(4, entry.getKey());
                    if (pstUp.executeUpdate() == 0) {
                        pstIns.setString(1, entry.getKey());
                        pstIns.setString(2, entry.getValue());
                        pstIns.setBoolean(3, esCorrecta);
                        pstIns.setInt(4, preguntaIdFinal);
                        pstIns.executeUpdate();
                    }
                }
            }

            con.commit();
            redirectAttributes.addFlashAttribute("mensajeDocente",
                    (idPregunta == null || idPregunta <= 0) ? "Pregunta guardada correctamente." : "Pregunta actualizada correctamente.");
        } catch (Exception e) {
            e.printStackTrace();
            if (con != null) {
                try {
                    con.rollback();
                } catch (SQLException ignored) {
                }
            }
            redirectAttributes.addFlashAttribute("errorDocente", "No se pudo guardar la pregunta.");
        } finally {
            if (con != null) {
                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ignored) {
                }
            }
        }

        return "redirect:/docente/dashboard#preguntas";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminarPregunta(@PathVariable("id") int idPregunta,
                                   HttpSession session,
                                   RedirectAttributes redirectAttributes) {
        if (!esDocente(session)) {
            return "redirect:/login";
        }

        String sql = "DELETE FROM PREGUNTA WHERE id_pregunta = ?";
        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idPregunta);
            pst.executeUpdate();
            redirectAttributes.addFlashAttribute("mensajeDocente", "Pregunta eliminada.");
        } catch (SQLException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorDocente", "No se puede eliminar la pregunta si ya fue respondida en un resultado.");
        }

        return "redirect:/docente/dashboard#preguntas";
    }
}