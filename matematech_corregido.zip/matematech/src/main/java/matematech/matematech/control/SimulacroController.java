package matematech.matematech.control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpSession;
import matematech.matematech.modelo.Usuario;

/**
 * Flujo del estudiante:
 *  1. Entra a la evaluación            -> GET  /evaluacion/{id}
 *  2. Recibe las preguntas              -> GET  /api/evaluaciones/{id}/preguntas   (sin revelar la correcta)
 *  3. Responde y finaliza               -> POST /api/evaluaciones/{id}/finalizar
 *  4. El servidor valida cada respuesta, suma el puntaje (1 punto por acierto),
 *     guarda RESULTADO + RESPUESTA y devuelve el resultado para mostrarlo.
 */
@Controller
public class SimulacroController {

    private Usuario estudianteEnSesion(HttpSession session) {
        Object attr = session.getAttribute("usuario");
        if (attr instanceof Usuario u && u.getRol() != null && "Estudiante".equalsIgnoreCase(u.getRol().trim())) {
            return u;
        }
        return null;
    }

    // ---------------------------------------------------------------- Página

    @GetMapping("/evaluacion")
    public String irADashboard(HttpSession session) {
        return estudianteEnSesion(session) == null ? "redirect:/login" : "redirect:/dashboard";
    }

    @GetMapping("/evaluacion/{id}")
    public String mostrarEvaluacion(@PathVariable("id") int idEvaluacion, HttpSession session, Model model) {
        if (estudianteEnSesion(session) == null) {
            return "redirect:/login";
        }

        Map<String, Object> evaluacion = EvaluacionController.buscarPorId(idEvaluacion);
        if (evaluacion == null) {
            return "redirect:/dashboard";
        }

        int minutos = (Integer) evaluacion.get("tiempoLimite");
        model.addAttribute("idEvaluacion", idEvaluacion);
        model.addAttribute("titulo", evaluacion.get("titulo"));
        model.addAttribute("tiempoLimite", minutos > 0 ? minutos : 60);
        return "login/evaluacion";
    }

    // ----------------------------------------------------------- API: preguntas

    @GetMapping("/api/evaluaciones/{id}/preguntas")
    @ResponseBody
    public ResponseEntity<?> obtenerPreguntas(@PathVariable("id") int idEvaluacion, HttpSession session) {
        if (estudianteEnSesion(session) == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Sesión no válida."));
        }

        String sql = """
                SELECT p.id_pregunta, p.enunciado, c.nombre AS competencia,
                       o.id_opcion, o.letra, o.texto
                FROM EVALUACION_PREGUNTA ep
                INNER JOIN PREGUNTA p ON p.id_pregunta = ep.id_pregunta
                INNER JOIN COMPETENCIA c ON c.id_competencia = p.id_competencia
                INNER JOIN OPCION o ON o.id_pregunta = p.id_pregunta
                WHERE ep.id_evaluacion = ?
                ORDER BY ep.ordenPregunta, p.id_pregunta, o.letra
                """;

        Connection con = UsuarioController.conectar();
        if (con == null) {
            return ResponseEntity.status(500).body(Map.of("error", "No hay conexión con la base de datos."));
        }

        Map<Integer, Map<String, Object>> preguntas = new LinkedHashMap<>();
        try (con; PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idEvaluacion);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    int idPregunta = rs.getInt("id_pregunta");
                    Map<String, Object> p = preguntas.get(idPregunta);
                    if (p == null) {
                        p = new LinkedHashMap<>();
                        p.put("id_pregunta", idPregunta);
                        p.put("enunciado", rs.getString("enunciado"));
                        p.put("competencia", rs.getString("competencia"));
                        p.put("opciones", new ArrayList<Map<String, Object>>());
                        preguntas.put(idPregunta, p);
                    }
                    Map<String, Object> op = new LinkedHashMap<>();
                    op.put("id_opcion", rs.getInt("id_opcion"));
                    op.put("letra", rs.getString("letra"));
                    op.put("texto", rs.getString("texto"));
                    // OJO: aquí NO se envía esCorrecta al navegador.
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> ops = (List<Map<String, Object>>) p.get("opciones");
                    ops.add(op);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("error", "Error al leer las preguntas."));
        }

        return ResponseEntity.ok(new ArrayList<>(preguntas.values()));
    }

    // ----------------------------------------------------- API: validar y guardar

    /** Datos de una pregunta con su clave de corrección (solo viven en el servidor). */
    private static class Clave {
        int idPregunta;
        String enunciado;
        String explicacion;
        String letraCorrecta;
        Map<String, Integer> idOpcionPorLetra = new LinkedHashMap<>();
    }

    @PostMapping("/api/evaluaciones/{id}/finalizar")
    @ResponseBody
    public ResponseEntity<?> finalizar(@PathVariable("id") int idEvaluacion,
                                       @RequestBody(required = false) Map<String, String> respuestas,
                                       HttpSession session) {
        Usuario estudiante = estudianteEnSesion(session);
        if (estudiante == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Sesión no válida."));
        }
        if (respuestas == null) {
            respuestas = Map.of();
        }

        String sqlClave = """
                SELECT p.id_pregunta, p.enunciado, p.explicacion,
                       o.id_opcion, o.letra, o.esCorrecta
                FROM EVALUACION_PREGUNTA ep
                INNER JOIN PREGUNTA p ON p.id_pregunta = ep.id_pregunta
                INNER JOIN OPCION o ON o.id_pregunta = p.id_pregunta
                WHERE ep.id_evaluacion = ?
                ORDER BY ep.ordenPregunta, p.id_pregunta, o.letra
                """;

        Connection con = UsuarioController.conectar();
        if (con == null) {
            return ResponseEntity.status(500).body(Map.of("error", "No hay conexión con la base de datos."));
        }

        try (con) {
            // 1) Cargar la clave de corrección desde la BD
            Map<Integer, Clave> claves = new LinkedHashMap<>();
            try (PreparedStatement pst = con.prepareStatement(sqlClave)) {
                pst.setInt(1, idEvaluacion);
                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        int idPregunta = rs.getInt("id_pregunta");
                        Clave c = claves.get(idPregunta);
                        if (c == null) {
                            c = new Clave();
                            c.idPregunta = idPregunta;
                            c.enunciado = rs.getString("enunciado");
                            c.explicacion = rs.getString("explicacion");
                            claves.put(idPregunta, c);
                        }
                        String letra = rs.getString("letra");
                        c.idOpcionPorLetra.put(letra, rs.getInt("id_opcion"));
                        if (rs.getBoolean("esCorrecta")) {
                            c.letraCorrecta = letra;
                        }
                    }
                }
            }

            if (claves.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "La evaluación no tiene preguntas."));
            }

            // 2) Validar cada respuesta y sumar el puntaje
            int total = claves.size();
            int correctas = 0;
            int sinResponder = 0;
            List<Map<String, Object>> detalle = new ArrayList<>();
            List<int[]> respuestasAGuardar = new ArrayList<>(); // {id_pregunta, id_opcion}

            for (Clave c : claves.values()) {
                String elegida = respuestas.get(String.valueOf(c.idPregunta));
                elegida = elegida == null ? null : elegida.trim().toUpperCase();
                boolean valida = elegida != null && c.idOpcionPorLetra.containsKey(elegida);
                boolean acierto = valida && elegida.equals(c.letraCorrecta);

                if (!valida) {
                    sinResponder++;
                } else {
                    respuestasAGuardar.add(new int[]{c.idPregunta, c.idOpcionPorLetra.get(elegida)});
                }
                if (acierto) {
                    correctas++;
                }

                Map<String, Object> d = new LinkedHashMap<>();
                d.put("id_pregunta", c.idPregunta);
                d.put("enunciado", c.enunciado);
                d.put("elegida", valida ? elegida : null);
                d.put("correcta", c.letraCorrecta);
                d.put("esCorrecta", acierto);
                d.put("explicacion", c.explicacion);
                detalle.add(d);
            }

            double puntaje = correctas; // 1 punto por respuesta correcta
            double porcentaje = Math.round((correctas * 100.0 / total) * 10.0) / 10.0;

            // 3) Guardar RESULTADO + RESPUESTA en una sola transacción
            int idResultado;
            con.setAutoCommit(false);
            try {
                String sqlResultado = "INSERT INTO RESULTADO (puntaje, porcentaje, fechaRealizacion, id_estudiante, id_evaluacion) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement pst = con.prepareStatement(sqlResultado, Statement.RETURN_GENERATED_KEYS)) {
                    pst.setDouble(1, puntaje);
                    pst.setDouble(2, porcentaje);
                    pst.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                    pst.setInt(4, estudiante.getId_usuario());
                    pst.setInt(5, idEvaluacion);
                    pst.executeUpdate();
                    try (ResultSet keys = pst.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("No se obtuvo el id del resultado.");
                        }
                        idResultado = keys.getInt(1);
                    }
                }

                if (!respuestasAGuardar.isEmpty()) {
                    String sqlRespuesta = "INSERT INTO RESPUESTA (id_resultado, id_pregunta, id_opcion) VALUES (?, ?, ?)";
                    try (PreparedStatement pst = con.prepareStatement(sqlRespuesta)) {
                        for (int[] r : respuestasAGuardar) {
                            pst.setInt(1, idResultado);
                            pst.setInt(2, r[0]);
                            pst.setInt(3, r[1]);
                            pst.addBatch();
                        }
                        pst.executeBatch();
                    }
                }
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }

            Map<String, Object> resultado = new LinkedHashMap<>();
            resultado.put("id_resultado", idResultado);
            resultado.put("total", total);
            resultado.put("correctas", correctas);
            resultado.put("incorrectas", total - correctas - sinResponder);
            resultado.put("sinResponder", sinResponder);
            resultado.put("puntaje", puntaje);
            resultado.put("porcentaje", porcentaje);
            resultado.put("detalle", detalle);
            return ResponseEntity.ok(resultado);

        } catch (SQLException e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("error", "No se pudo guardar el resultado: " + e.getMessage()));
        }
    }
}
