package matematech.matematech.control;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import matematech.matematech.modelo.Usuario;

@Controller
@RequestMapping("/docente")
public class DocenteController {

    public static class Docente extends Usuario {
        private String asignatura;

        public String getAsignatura() {
            return asignatura;
        }

        public void setAsignatura(String asignatura) {
            this.asignatura = asignatura;
        }
    }

    public static Docente buscarDocentePorId(int idUsuario) {
        String sql = """
                SELECT u.id_usuario, u.nombre, u.correo, u.contrasena, u.rol, d.asignatura
                FROM USUARIO u
                INNER JOIN DOCENTE d ON u.id_usuario = d.id_usuario
                WHERE u.id_usuario = ?
                """;

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idUsuario);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    Docente docente = new Docente();
                    docente.setId_usuario(rs.getInt("id_usuario"));
                    docente.setNombre(rs.getString("nombre"));
                    docente.setCorreo(rs.getString("correo"));
                    docente.setContrasena(rs.getString("contrasena"));
                    docente.setRol(rs.getString("rol"));
                    docente.setAsignatura(rs.getString("asignatura"));
                    return docente;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping("/dashboard")
    public String mostrarDashboardDocente(@RequestParam(required = false) Integer editarEvalId,
                                          @RequestParam(required = false) Integer editarPregId,
                                          HttpSession session,
                                          Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null || !"Docente".equalsIgnoreCase(usuario.getRol())) {
            session.invalidate();
            return "redirect:/login";
        }

        Docente docente = buscarDocentePorId(usuario.getId_usuario());
        List<Map<String, Object>> evaluaciones = EvaluacionController.listarEvaluaciones();
        var estudiantes = UsuarioController.obtenerEstudiantes();
        List<Map<String, Object>> preguntas = PreguntaController.listarPreguntas();
        List<Map<String, Object>> competencias = PreguntaController.listarCompetencias();
        List<Map<String, Object>> resultados = ResultadoController.listarResultadosEstudiantes();
        List<Map<String, Object>> estadisticasCompetencia = ResultadoController.calcularEstadisticasPorCompetencia();

        Map<String, Object> evaluacionEditar = editarEvalId != null
                ? EvaluacionController.buscarPorId(editarEvalId) : null;

        Map<String, Object> preguntaEditar = editarPregId != null
                ? PreguntaController.buscarPreguntaParaEditar(editarPregId) : null;

        model.addAttribute("usuario", docente != null ? docente : usuario);
        model.addAttribute("docente", docente);
        model.addAttribute("estudiantes", estudiantes);
        model.addAttribute("evaluaciones", evaluaciones);
        model.addAttribute("totalEvaluaciones", evaluaciones.size());
        model.addAttribute("preguntas", preguntas);
        model.addAttribute("competencias", competencias);
        model.addAttribute("resultados", resultados);
        model.addAttribute("estadisticasCompetencia", estadisticasCompetencia);
        model.addAttribute("evaluacionEditar", evaluacionEditar);
        model.addAttribute("preguntaEditar", preguntaEditar);

        return "login/docente";
    }

    @PostMapping("/asignatura")
    public String actualizarAsignatura(@RequestParam String asignatura,
                                       HttpSession session,
                                       RedirectAttributes redirectAttributes) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null || !"Docente".equalsIgnoreCase(usuario.getRol())) {
            return "redirect:/login";
        }

        String sql = "UPDATE DOCENTE SET asignatura = ? WHERE id_usuario = ?";
        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, asignatura.trim());
            pst.setInt(2, usuario.getId_usuario());
            pst.executeUpdate();
            redirectAttributes.addFlashAttribute("mensajeDocente", "Asignatura actualizada correctamente.");
        } catch (SQLException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorDocente", "No se pudo actualizar la asignatura.");
        }

        return "redirect:/docente/dashboard";
    }
}