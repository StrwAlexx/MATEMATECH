package matematech.matematech.control;

import org.springframework.stereotype.Controller;

import java.sql.*;
import java.util.*;

@Controller
public class ResultadoController {

    public static List<Map<String, Object>> listarResultadosEstudiantes() {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = """
                SELECT r.id_resultado, r.id_estudiante, u.nombre AS estudiante_nombre, u.correo AS estudiante_correo,
                       e.titulo AS evaluacion_titulo, r.puntaje, r.porcentaje, r.fechaRealizacion
                FROM RESULTADO r
                INNER JOIN USUARIO u ON r.id_estudiante = u.id_usuario
                INNER JOIN EVALUACION e ON r.id_evaluacion = e.id_evaluacion
                ORDER BY r.id_resultado DESC
                """;

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> fila = new LinkedHashMap<>();
                fila.put("id_resultado", rs.getInt("id_resultado"));
                fila.put("id_estudiante", rs.getInt("id_estudiante"));
                fila.put("estudiante_nombre", rs.getString("estudiante_nombre"));
                fila.put("estudiante_correo", rs.getString("estudiante_correo"));
                fila.put("evaluacion_titulo", rs.getString("evaluacion_titulo"));
                fila.put("puntaje", rs.getDouble("puntaje"));
                fila.put("porcentaje", rs.getDouble("porcentaje"));
                fila.put("fechaRealizacion", rs.getDate("fechaRealizacion"));
                lista.add(fila);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public static List<Map<String, Object>> calcularEstadisticasPorCompetencia() {
        List<Map<String, Object>> estadisticas = new ArrayList<>();
        String sql = """
                SELECT c.id_competencia, c.nombre AS competencia, c.componente,
                       COUNT(resp.id_respuesta) AS total_respuestas,
                       SUM(CASE WHEN op.esCorrecta = TRUE THEN 1 ELSE 0 END) AS correctas
                FROM COMPETENCIA c
                LEFT JOIN PREGUNTA p ON p.id_competencia = c.id_competencia
                LEFT JOIN RESPUESTA resp ON resp.id_pregunta = p.id_pregunta
                LEFT JOIN OPCION op ON resp.id_opcion = op.id_opcion
                GROUP BY c.id_competencia, c.nombre, c.componente
                ORDER BY c.id_competencia ASC
                """;

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                int total = rs.getInt("total_respuestas");
                int correctas = rs.getInt("correctas");
                double porcentaje = total > 0 ? (correctas * 100.0) / total : 0.0;

                Map<String, Object> item = new LinkedHashMap<>();
                item.put("id_competencia", rs.getInt("id_competencia"));
                item.put("competencia", rs.getString("competencia"));
                item.put("componente", rs.getString("componente"));
                item.put("total_respuestas", total);
                item.put("correctas", correctas);
                item.put("porcentaje", Math.round(porcentaje * 10.0) / 10.0);
                estadisticas.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return estadisticas;
    }
}