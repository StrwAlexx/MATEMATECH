package matematech.matematech.control;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;
import matematech.matematech.modelo.Usuario;

@Controller
@RequestMapping("/docente/evaluaciones")
public class EvaluacionController {

    private boolean esDocente(HttpSession session) {
        if (session == null) {
            return false;
        }
        Object attr = session.getAttribute("usuario");
        if (!(attr instanceof Usuario u)) {
            return false;
        }
        return u.getRol() != null && "Docente".equalsIgnoreCase(u.getRol().trim());
    }

    public static List<Map<String, Object>> listarEvaluaciones() {
        List<Map<String, Object>> lista = new ArrayList<>();
        String sql = """
                SELECT e.id_evaluacion, e.titulo, e.descripcion, e.tiempoLimite, e.fechaCreacion,
                       (SELECT COUNT(*) FROM EVALUACION_PREGUNTA ep WHERE ep.id_evaluacion = e.id_evaluacion) AS total_preguntas
                FROM EVALUACION e
                ORDER BY e.id_evaluacion DESC
                """;

        Connection con = UsuarioController.conectar();
        if (con == null) {
            return lista;
        }

        try (con;
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Map<String, Object> fila = new LinkedHashMap<>();
                fila.put("id_evaluacion", rs.getInt("id_evaluacion"));
                fila.put("titulo", rs.getString("titulo"));
                fila.put("descripcion", rs.getString("descripcion"));
                fila.put("tiempoLimite", rs.getInt("tiempoLimite"));
                fila.put("fechaCreacion", rs.getDate("fechaCreacion"));
                fila.put("total_preguntas", rs.getInt("total_preguntas"));
                lista.add(fila);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    public static Map<String, Object> buscarPorId(int idEvaluacion) {
        String sql = "SELECT id_evaluacion, titulo, descripcion, tiempoLimite, fechaCreacion FROM EVALUACION WHERE id_evaluacion = ?";

        Connection con = UsuarioController.conectar();
        if (con == null) {
            return null;
        }

        try (con;
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idEvaluacion);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    Map<String, Object> fila = new LinkedHashMap<>();
                    fila.put("id_evaluacion", rs.getInt("id_evaluacion"));
                    fila.put("titulo", rs.getString("titulo"));
                    fila.put("descripcion", rs.getString("descripcion"));
                    fila.put("tiempoLimite", rs.getInt("tiempoLimite"));
                    fila.put("fechaCreacion", rs.getDate("fechaCreacion"));
                    return fila;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @GetMapping("/guardar")
    public String redirigirGuardarGet(HttpSession session) {
        if (!esDocente(session)) {
            return "redirect:/login";
        }
        return "redirect:/docente/dashboard#evaluaciones";
    }

    @PostMapping("/guardar")
    public String guardarEvaluacion(@RequestParam(name = "idEvaluacion", required = false) String idEvaluacionRaw,
                                    @RequestParam(name = "titulo") String titulo,
                                    @RequestParam(name = "descripcion", required = false, defaultValue = "") String descripcion,
                                    @RequestParam(name = "tiempoLimite", required = false, defaultValue = "60") int tiempoLimite,
                                    HttpSession session,
                                    RedirectAttributes redirectAttributes) {
        if (!esDocente(session)) {
            return "redirect:/login";
        }

        if (titulo == null || titulo.trim().isEmpty()) {
            redirectAttributes.addFlashAttribute("errorDocente", "El título de la evaluación es obligatorio.");
            return "redirect:/docente/dashboard#evaluaciones";
        }

        Integer idEvaluacion = null;
        if (idEvaluacionRaw != null && !idEvaluacionRaw.trim().isEmpty()) {
            try {
                idEvaluacion = Integer.valueOf(idEvaluacionRaw.trim());
            } catch (NumberFormatException ignored) {
                idEvaluacion = null;
            }
        }

        Connection con = UsuarioController.conectar();
        if (con == null) {
            redirectAttributes.addFlashAttribute("errorDocente", "No se pudo conectar a la base de datos MySQL.");
            return "redirect:/docente/dashboard#evaluaciones";
        }

        try (con) {
            if (idEvaluacion == null || idEvaluacion <= 0) {
                String sql = "INSERT INTO EVALUACION (titulo, descripcion, tiempoLimite, fechaCreacion) VALUES (?, ?, ?, ?)";
                try (PreparedStatement pst = con.prepareStatement(sql)) {
                    pst.setString(1, titulo.trim());
                    pst.setString(2, descripcion != null ? descripcion.trim() : "");
                    pst.setInt(3, tiempoLimite);
                    pst.setDate(4, Date.valueOf(LocalDate.now()));
                    pst.executeUpdate();
                    redirectAttributes.addFlashAttribute("mensajeDocente", "Evaluación creada correctamente.");
                }
            } else {
                String sql = "UPDATE EVALUACION SET titulo = ?, descripcion = ?, tiempoLimite = ? WHERE id_evaluacion = ?";
                try (PreparedStatement pst = con.prepareStatement(sql)) {
                    pst.setString(1, titulo.trim());
                    pst.setString(2, descripcion != null ? descripcion.trim() : "");
                    pst.setInt(3, tiempoLimite);
                    pst.setInt(4, idEvaluacion);
                    pst.executeUpdate();
                    redirectAttributes.addFlashAttribute("mensajeDocente", "Evaluación actualizada correctamente.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorDocente", "Error SQL al guardar evaluación: " + e.getMessage());
        }

        return "redirect:/docente/dashboard#evaluaciones";
    }

    @PostMapping("/eliminar/{id}")
    public String eliminarEvaluacion(@PathVariable("id") int idEvaluacion,
                                     HttpSession session,
                                     RedirectAttributes redirectAttributes) {
        if (!esDocente(session)) {
            return "redirect:/login";
        }

        String sql = "DELETE FROM EVALUACION WHERE id_evaluacion = ?";
        Connection con = UsuarioController.conectar();
        if (con == null) {
            redirectAttributes.addFlashAttribute("errorDocente", "No se pudo conectar a la base de datos MySQL.");
            return "redirect:/docente/dashboard#evaluaciones";
        }

        try (con;
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, idEvaluacion);
            pst.executeUpdate();
            redirectAttributes.addFlashAttribute("mensajeDocente", "Evaluación eliminada.");
        } catch (SQLException e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("errorDocente", "No se pudo eliminar la evaluación.");
        }

        return "redirect:/docente/dashboard#evaluaciones";
    }
}