package com.matematech.matematech.control;

import com.matematech.matematech.modelo.Usuario;
import com.matematech.matematech.control.UsuarioController;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @GetMapping({"/", "/login"})
    public String mostrarLogin() {
        return "login/login";
    }

    @PostMapping("/login")
    public String procesarLogin(@RequestParam String correo,
                                @RequestParam String contrasena,
                                HttpSession session,
                                Model model) {

        Usuario encontrado = UsuarioController.buscarPorCorreoYContrasena(correo, contrasena);

        if (encontrado != null) {
            session.setAttribute("usuario", encontrado);

            // Redirección según el rol de la base de datos ('Docente' o 'Estudiante')
            if ("Docente".equalsIgnoreCase(encontrado.getRol())) {
                return "redirect:/docente/dashboard";
            } else {
                return "redirect:/dashboard";
            }
        }

        model.addAttribute("error", "Correo o contraseña incorrectos.");
        return "login/login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "login/registro";
    }

    @PostMapping("/registro")
    public String procesarRegistro(Usuario usuario,
                                   @RequestParam(required = false) String codigoAdmin,
                                   Model model) {

        if ("DOCENTE".equalsIgnoreCase(usuario.getRol())) {
            usuario.setRol("Docente");
            if (codigoAdmin == null || !codigoAdmin.equals("ADMIN*")) {
                model.addAttribute("error", "Código de autorización docente incorrecto.");
                model.addAttribute("usuario", usuario);
                return "login/registro";
            }
        } else {
            usuario.setRol("Estudiante");
        }

        boolean exito = UsuarioController.guardar(usuario);
        if (!exito) {
            model.addAttribute("error", "El correo ya se encuentra registrado o hubo un error en la base de datos.");
            model.addAttribute("usuario", usuario);
            return "login/registro";
        }

        return "redirect:/login?registrado=true";
    }

    @GetMapping("/dashboard")
    public String mostrarDashboardEstudiante(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null || !"Estudiante".equalsIgnoreCase(usuario.getRol())) {
            session.invalidate();
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);
        return "login/dashboard";
    }

    @GetMapping("/docente/dashboard")
    public String mostrarDashboardDocente(HttpSession session, Model model) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario == null || !"Docente".equalsIgnoreCase(usuario.getRol())) {
            session.invalidate();
            return "redirect:/login";
        }

        model.addAttribute("usuario", usuario);
        model.addAttribute("estudiantes", UsuarioController.obtenerEstudiantes());
        return "login/docente";
    }

    @GetMapping("/logout")
    public String cerrarSesion(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}