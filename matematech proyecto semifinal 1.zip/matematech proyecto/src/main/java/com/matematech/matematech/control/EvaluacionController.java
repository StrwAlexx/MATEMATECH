package com.matematech.matematech.control;

import com.matematech.matematech.modelo.Evaluacion;
import com.matematech.matematech.control.UsuarioController;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/evaluaciones")
public class EvaluacionController {

    @GetMapping
    public List<Evaluacion> listar() {
        List<Evaluacion> lista = new ArrayList<>();
        String sql = "SELECT * FROM EVALUACION";

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Evaluacion e = new Evaluacion();
                e.setId_evaluacion(rs.getInt("id_evaluacion"));
                e.setTitulo(rs.getString("titulo"));
                e.setDescripcion(rs.getString("descripcion"));
                e.setTiempoLimite(rs.getInt("tiempo_limite"));
                e.setFechaCreacion(rs.getDate("fecha_creacion"));
                lista.add(e);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    @GetMapping("/{id}")
    public Evaluacion buscar(@PathVariable int id) {
        Evaluacion evaluacion = null;
        String sql = "SELECT * FROM EVALUACION WHERE id_evaluacion = ?";

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                evaluacion = new Evaluacion();
                evaluacion.setId_evaluacion(rs.getInt("id_evaluacion"));
                evaluacion.setTitulo(rs.getString("titulo"));
                evaluacion.setDescripcion(rs.getString("descripcion"));
                evaluacion.setTiempoLimite(rs.getInt("tiempo_limite"));
                evaluacion.setFechaCreacion(rs.getDate("fecha_creacion"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return evaluacion;
    }

    @PostMapping
    public String agregar(@RequestBody Evaluacion evaluacion) {
        String sql = "INSERT INTO EVALUACION (titulo, descripcion, tiempo_limite, fecha_creacion) VALUES (?, ?, ?, NOW())";

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, evaluacion.getTitulo());
            pst.setString(2, evaluacion.getDescripcion());
            pst.setInt(3, evaluacion.getTiempoLimite());
            pst.executeUpdate();
            return "Evaluación agregada correctamente a la base de datos.";
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error al agregar la evaluación: " + e.getMessage();
        }
    }

    @PutMapping("/{id}")
    public String actualizar(@PathVariable int id, @RequestBody Evaluacion nueva) {
        String sql = "UPDATE EVALUACION SET titulo = ?, descripcion = ?, tiempo_limite = ? WHERE id_evaluacion = ?";

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setString(1, nueva.getTitulo());
            pst.setString(2, nueva.getDescripcion());
            pst.setInt(3, nueva.getTiempoLimite());
            pst.setInt(4, id);

            int filas = pst.executeUpdate();
            if (filas > 0) {
                return "Evaluación actualizada correctamente.";
            } else {
                return "Evaluación no encontrada.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error al actualizar: " + e.getMessage();
        }
    }

    @DeleteMapping("/{id}")
    public String eliminar(@PathVariable int id) {
        String sql = "DELETE FROM EVALUACION WHERE id_evaluacion = ?";

        try (Connection con = UsuarioController.conectar();
             PreparedStatement pst = con.prepareStatement(sql)) {
            pst.setInt(1, id);

            int filas = pst.executeUpdate();
            if (filas > 0) {
                return "Evaluación eliminada correctamente.";
            } else {
                return "Evaluación no encontrada.";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error al eliminar: " + e.getMessage();
        }
    }
}